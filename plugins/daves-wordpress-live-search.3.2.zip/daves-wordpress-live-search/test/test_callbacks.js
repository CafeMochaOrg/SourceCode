LiveSearch.addCallback('BeforeShowResults', function() { console.log('BeforeShowResults'); });
LiveSearch.addCallback('AfterShowResults', function() { console.log('AfterShowResults'); });
LiveSearch.addCallback('BeforeHideResults', function() { console.log('BeforeHideResults'); });
LiveSearch.addCallback('AfterHideResults', function() { console.log('AfterHideResults'); });
